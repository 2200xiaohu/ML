""" REST APIs documented and sensible
"""
from Smile import *

__version__ = '0.0.1'


# EOF
